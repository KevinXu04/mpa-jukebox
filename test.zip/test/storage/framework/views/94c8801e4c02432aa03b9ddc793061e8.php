<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>Spotifu - Login</title>

        <!-- Fonts -->
        <link rel="preconnect" href="https://fonts.bunny.net">
        <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Open+Sans">
        <link href="https://fonts.bunny.net/css?family=figtree:400,600&display=swap" rel="stylesheet" />
        
        <!-- CSS -->
        <link rel="stylesheet" type="text/css" href="<?php echo e(url('/css/style.css')); ?>" />

        <!-- Font Awesome -->
        <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css" />
    </head>

    <body>

    <div class="loginContainer">
    <div class="secondContainer">
        <h1>Login</h1>
        <div class="overlay" id="Login">
            <div class="wrapper">
                <div class="content">
                    <div class="formContainer">
                        <?php if($errors->any()): ?>
                            <div class="alert alert-danger">
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php echo e($error); ?>

                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        <?php endif; ?>
                        <form method="POST" action="<?php echo e(route('login')); ?>">
                            <?php echo csrf_field(); ?>
                            <label>Email</label>
                            <input type="email" name="email" placeholder="Your email" value="<?php echo e(old('email')); ?>" required>
                            <label>Password</label>
                            <input type="password" name="password" placeholder="Your password" required>
                            <input type="submit" value="Login">
                            <p>Don't have an account yet? <a href="<?php echo e(route('register')); ?>">Sign up!</a></p>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
    </body>

</html>
<?php /**PATH C:\School\DaVinci\github\mpa-jukebox\test\resources\views/auth/app.blade.php ENDPATH**/ ?>