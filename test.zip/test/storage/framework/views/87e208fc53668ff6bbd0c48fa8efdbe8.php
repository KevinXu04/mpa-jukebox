<header>
    <nav>
        <ul>
            <li><a href="/"><img src="<?php echo e(URL('/images/spotify.png')); ?>" alt="" class="logo">Spotifu</a></li>
            <li><a href="/search"><img src="<?php echo e(URL('/images/search.png')); ?>" alt="" class="icon">Search</a></li>
        </ul>

        <?php if(Session::has('user_id')): ?>
            <?php
                $user = Session::get('user');
            ?>
            <p>Welcome, <?php echo e($user->name); ?></p>
        <?php else: ?>
            <p>No user is logged in.</p>
        <?php endif; ?>

    </nav>

    <nav>
        <div class="createList">
            <h1>Library</h1>
            <?php if(Session::has('user_id')): ?>
                <form method="post" action="<?php echo e(route('createPlaylist')); ?>">
                    <?php echo csrf_field(); ?>
                    <label for="playlist_name">Playlist Name:</label>
                    <input type="text" id="playlist_name" name="playlist_name" placeholder="Enter a name" required>
                    <button type="submit">Create Playlist</button>
                </form>
            <?php else: ?>
                <p>You need to <a href="/" class="underline">login</a> to create playlists.</p>
            <?php endif; ?>
        </div>

        <h3>Playlists</h3>

        <div class="playlists">
            <?php $__currentLoopData = $playlists; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $playlist): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="list" onclick="showPlaylistSongsModal('<?php echo e($playlist->id); ?>')">
                    <img src="<?php echo e(url('/images/liked.png')); ?>" alt="">
                    <div class="information">
                        <div class="playlistName">
                            <?php echo e($playlist->name); ?>

                        </div>
                        
                        <div class="playlistInfo">
                            <?php
                                $user = Session::get('user');
                            ?>
                            Playlist • <?php echo e($user->name); ?>

                        </div>
                        <div class="songsAmount">
                            <?php echo e($playlist->song_count); ?> Songs
                        </div>
                    </div>
                </div>

                <!-- Playlist name update form -->
                <div>
                    <form action="<?php echo e(route('playlist.update', ['playlistId' => $playlist->id])); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <input type="text" name="playlist_name" value="<?php echo e($playlist->name); ?>" required>
                        <button type="submit">Update Name</button>
                    </form>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </nav>
</header>
<?php /**PATH C:\School\DaVinci\github\mpa-jukebox\test\resources\views/includes/header.blade.php ENDPATH**/ ?>