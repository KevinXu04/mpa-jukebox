<h1>Popular Songs</h1>

<div class="song-slider">
    <?php
    $results = DB::table('songs')->get();

    foreach ($results as $result) {
        echo '
        <div class="song">
            <div class="song-image">
                <img src="' . $result->image . '" alt="">    
            </div>
            <div class="song-title">
                ' . $result->name . '
            </div>
            <div class="song-author">
                ' . $result->author . '
            </div>
        </div>';
    }
    ?>      
</div><?php /**PATH C:\School\DaVinci\github\mpa-jukebox\test\resources\views/pages/home.blade.php ENDPATH**/ ?>