

<?php $__env->startSection('register'); ?>
    <div class="loginContainer">
        <div class="secondContainer">
            <h1>Register</h1>
            <div class="overlay" id="Register">
                <div class="wrapper">
                    <div class="content">
                        <div class="formContainer">
                            <?php if($errors->any()): ?>
                                <div class="alert alert-danger">
                                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php echo e($error); ?>

                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                            <?php endif; ?>
                            <form method="POST" action="<?php echo e(route('register')); ?>">
                                <?php echo csrf_field(); ?>
                                <label>Username</label>
                                <input type="text" name="name" placeholder="Your username" required>
                                <label>Email</label>
                                <input type="email" name="email" placeholder="Your email" required>
                                <label>Password</label>
                                <input type="password" name="password" placeholder="Your password" required>
                                <label>Confirm Password</label>
                                <input type="password" name="password_confirmation" placeholder="Confirm your password" required>
                                <input type="submit" value="Register">
                                <p>Already have an account? <a href="/">Sign in!</a></p>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\School\DaVinci\github\mpa-jukebox\test\resources\views/register.blade.php ENDPATH**/ ?>