<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>Spotifu - Login</title>

        <!-- Fonts -->
        <link rel="preconnect" href="https://fonts.bunny.net">
        <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Open+Sans">
        <link href="https://fonts.bunny.net/css?family=figtree:400,600&display=swap" rel="stylesheet" />
        
        <!-- CSS -->
        <link rel="stylesheet" type="text/css" href="<?php echo e(url('/css/style.css')); ?>" />

        <!-- Font Awesome -->
        <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css" />
    </head>

    <body>

        <div class="loginContainer">
            <div class="secondContainer">
                <a href="/register" class="button">Register</a>
                <a href="/login" class="button">Login</a>

                <div class="overlay" id="Login">
                    <div class="wrapper">
                        <!-- <a href="#" class="close">X</a> -->
                        <div class="content">
                            <div class="formContainer">
                                <form action="/login" method="POST">
                                    <?php echo csrf_field(); ?>
                                    <label>Username</label>
                                    <input type="text" name="name" placeholder="Your username">
                                    <label>Password</label>
                                    <input type="password" name="password" placeholder="Your password">
                                    <input type="submit" value="Login">
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </body>

</html>
<?php /**PATH C:\School\DaVinci\github\mpa-jukebox\test\resources\views/login.blade.php ENDPATH**/ ?>