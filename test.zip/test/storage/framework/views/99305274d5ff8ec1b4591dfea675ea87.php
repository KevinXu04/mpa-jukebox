<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>Spotifu - Search</title>

        <!-- Fonts -->
        <link rel="preconnect" href="https://fonts.bunny.net">
        <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Open+Sans">
        <link href="https://fonts.bunny.net/css?family=figtree:400,600&display=swap" rel="stylesheet" />

        <!-- CSS -->
        <link rel="stylesheet" type="text/css" href="<?php echo e(url('/css/style.css')); ?>" />

        <!-- Font Awesome -->
        <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css" />
    </head>

    <body>
        
        <?php echo $__env->make('includes.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <div class="container">
            <h1>Search</h1>

            <div class="search-container">
                <!-- <input type="text" placeholder="Search.." name="search">
                <button type="submit"><i class="fa fa-search"></i></button> -->

                <form action="" method="get">
                    <select name="genre">
                        <option value="">All Genres</option>
                        <option value="rock">Rock</option>
                        <option value="pop">Pop</option>
                        <!-- Add more genre options as needed -->
                    </select>
                    <button type="submit">Filter</button>
                </form>

            </div>

            
        </div>


    </body>

</html>
<?php /**PATH C:\School\DaVinci\github\mpa-jukebox\test\resources\views/search.blade.php ENDPATH**/ ?>