

<?php $__env->startSection('home'); ?>
    <div class="fakeBody">
        <?php echo $__env->make('includes.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <div class="container">
            <h1>Popular Songs</h1>
            <?php if(session('success')): ?>
                <div class="alert alert-success">
                    <?php echo e(session('success')); ?>

                </div>
            <?php endif; ?>
            <?php if($errors->any()): ?>
                <div class="alert alert-danger">
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php echo e($error); ?>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            <?php endif; ?>

            <div class="context">
                <div class="filter-container">
                    <form action="<?php echo e(route('showFilterResult')); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <select name="genre">
                            <option value="">All Genres</option>
                            <?php $__currentLoopData = $genres; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $genre): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($genre->name); ?>"><?php echo e($genre->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <button type="submit">Filter</button>
                    </form>
                </div>
            </div>

            <br>

            <div class="song-slider">
                <?php $__currentLoopData = $results; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $result): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="song" onclick="showSongModal('<?php echo e($result->id); ?>', '<?php echo e($result->name); ?>', '<?php echo e($result->author); ?>', '<?php echo e($result->image); ?>')">
                        <div class="song-image">
                            <img src="<?php echo e($result->image); ?>" alt="">
                        </div>
                        <div class="song-title">
                            <?php echo e($result->name); ?>

                        </div>
                        <div class="song-author">
                            <?php echo e($result->author); ?>

                        </div>
                        <div class="playlist-button" onclick="createPlaylistModal('<?php echo e($result->id); ?>', '<?php echo e($result->name); ?>', '<?php echo e($result->author); ?>')">
                            &#43;
                        </div>
                        <div class="play-button">
                            &#9658;
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>

            <div class="hidden">
                
            </div>

            <div id="playlistModal" class="modal">
                <div class="modal-content">
                    <span class="close" onclick="closeModal()">&times;</span>
                    <h2>Add to Playlist</h2>
                    <form id="addSongForm" method="POST" action="<?php echo e(route('addSongToPlaylist')); ?>">
                        <?php echo csrf_field(); ?>
                        <input type="hidden" name="song_id" id="modalSongId">
                        <input type="hidden" name="song_name" id="modalSongName">
                        <input type="hidden" name="song_author" id="modalSongAuthor">

                        <label for="playlist">Select Playlist:</label>
                        <select name="saved_lists_id" id="playlistSelect">
                            <?php $__currentLoopData = $playlists; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $playlist): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($playlist->id); ?>"><?php echo e($playlist->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <button type="submit">Add to Playlist</button>
                    </form>
                </div>
            </div>

            <div id="songModal" class="modal">
                <div class="modal-content">
                    <span class="close" onclick="closeModal()">&times;</span>
                    <h2>Song Information</h2>

                    <div class="modal-container">
                        <div class="modal-image">
                            <img src="" alt="" id="songInfoImage">
                        </div>
                        <div class="modal-information">
                            <p id="songInfoId"></p>
                            <p id="songInfoName"></p>
                            <p id="songInfoAuthor"></p>
                        </div>
                    </div>
                </div>
            </div>

            <div id="playlistSongsModal" class="modal">
                <div class="modal-content">
                    <span class="close" onclick="closeModal('playlistSongsModal')">&times;</span>
                    <h2>Playlist Songs</h2>
                    <ul id="playlistSongsList"></ul>
                </div>
            </div>
        </div>
    </div>

    <script src="<?php echo e(url('/js/script.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\School\DaVinci\github\mpa-jukebox\test\resources\views/home.blade.php ENDPATH**/ ?>